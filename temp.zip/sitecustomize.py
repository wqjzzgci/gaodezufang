import importlib
import sys
importlib.reload(sys)