class ItemStruct:
    FID=1
    POINTID=1
    GRID=1
    ID=1
    def __init__(self):
        self.name=1

